/**
 * DEMO ONLY. Bind this Apps Script project to a test spreadsheet and set
 * SPREADSHEET_ID in Script Properties before deployment. No credentials here.
 */
const SHEET_NAME = 'Assessments';

function doGet() {
  return json_({ ok: true, service: 'Stroke Assessment demo', version: '1.0' });
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) throw new Error('Missing request body');
    const data = JSON.parse(e.postData.contents);
    validate_(data);
    const props = PropertiesService.getScriptProperties();
    const spreadsheetId = props.getProperty('SPREADSHEET_ID');
    if (!spreadsheetId) throw new Error('Set SPREADSHEET_ID in Script Properties');
    const ss = SpreadsheetApp.openById(spreadsheetId);
    const sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sheet.getLastRow() === 0) sheet.appendRow([
      'Created at', 'Demo reference', 'Exam date', 'Interval', 'Barthel round', 'Examiner alias',
      'NIHSS total', 'NIHSS item scores JSON', 'Barthel total', 'Barthel item scores JSON'
    ]);
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      sheet.appendRow([
        new Date(), safeCell_(data.recordId), safeCell_(data.examDate), safeCell_(data.interval),
        Number(data.barthelRound), safeCell_(data.examiner), Number(data.nihss),
        JSON.stringify(data.nihssScores), Number(data.barthel), JSON.stringify(data.barthelScores)
      ]);
    } finally { lock.releaseLock(); }
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

function validate_(d) {
  if (!d || typeof d !== 'object') throw new Error('Invalid record');
  if (!/^[A-Za-z0-9_-]{1,32}$/.test(String(d.recordId || ''))) throw new Error('Use a fictional alphanumeric reference');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(d.examDate || ''))) throw new Error('Invalid exam date');
  if (![1, 2, 3, 4, 5].includes(Number(d.barthelRound))) throw new Error('Invalid Barthel round');
  if (!Number.isInteger(Number(d.nihss)) || Number(d.nihss) < 0 || Number(d.nihss) > 42) throw new Error('Invalid NIHSS total');
  if (!Number.isInteger(Number(d.barthel)) || Number(d.barthel) < 0 || Number(d.barthel) > 100) throw new Error('Invalid Barthel total');
  if (!d.nihssScores || !d.barthelScores) throw new Error('Missing item scores');
}

function safeCell_(value) {
  const s = String(value == null ? '' : value).slice(0, 500);
  return /^[=+@\-]/.test(s) ? "'" + s : s;
}

function json_(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
